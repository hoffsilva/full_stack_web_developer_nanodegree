# Movie's trailer site

## Description
This site is the first final project of Full Stack Web Developer Nanodegree of Udacity.
Server side to store and show movies' posters, youtube link, overview and etc.

## Minimum Requirements

* Show list movies with posters and youtube video link.

## How to run

* Download It.
* Run: python entertainment_center.py
* Wait that your web browser will opened automatically.

### Bonus

* This site is consuming The Movie DB API.




